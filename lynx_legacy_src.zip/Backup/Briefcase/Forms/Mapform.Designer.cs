namespace Lynx
{
    partial class Mapform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Normal");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Grouped");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("View", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Script Editor", new System.Windows.Forms.TreeNode[] {
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Viewer");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Reference Editor", new System.Windows.Forms.TreeNode[] {
            treeNode5});
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tv1 = new System.Windows.Forms.TreeView();
            this.seviewnormpanel = new System.Windows.Forms.Panel();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.replacebox = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.findbox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.scriptbox = new System.Windows.Forms.TextBox();
            this.reeipanel = new System.Windows.Forms.Panel();
            this.listv = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.button12 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.repanel = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.sepanel = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.seviewgpanel = new System.Windows.Forms.Panel();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.tv2 = new System.Windows.Forms.TreeView();
            this.ctms2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.rtool = new System.Windows.Forms.ToolStripMenuItem();
            this.ttb1 = new System.Windows.Forms.ToolStripTextBox();
            this.renamet = new System.Windows.Forms.ToolStripMenuItem();
            this.rmtool = new System.Windows.Forms.ToolStripMenuItem();
            this.stool = new System.Windows.Forms.ToolStripSeparator();
            this.atool = new System.Windows.Forms.ToolStripMenuItem();
            this.ttb2 = new System.Windows.Forms.ToolStripTextBox();
            this.addt = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ctms3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.rt = new System.Windows.Forms.ToolStripMenuItem();
            this.ttb3 = new System.Windows.Forms.ToolStripTextBox();
            this.rentool = new System.Windows.Forms.ToolStripMenuItem();
            this.rmt = new System.Windows.Forms.ToolStripMenuItem();
            this.st = new System.Windows.Forms.ToolStripSeparator();
            this.at = new System.Windows.Forms.ToolStripMenuItem();
            this.ttb4 = new System.Windows.Forms.ToolStripTextBox();
            this.ttb5 = new System.Windows.Forms.ToolStripTextBox();
            this.adtol = new System.Windows.Forms.ToolStripMenuItem();
            this.o = new System.Windows.Forms.OpenFileDialog();
            this.s = new System.Windows.Forms.SaveFileDialog();
            this.ox = new System.Windows.Forms.OpenFileDialog();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.seviewnormpanel.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.reeipanel.SuspendLayout();
            this.repanel.SuspendLayout();
            this.sepanel.SuspendLayout();
            this.seviewgpanel.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.ctms2.SuspendLayout();
            this.ctms3.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tv1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.repanel);
            this.splitContainer1.Panel2.Controls.Add(this.sepanel);
            this.splitContainer1.Panel2.Controls.Add(this.seviewgpanel);
            this.splitContainer1.Panel2.Controls.Add(this.seviewnormpanel);
            this.splitContainer1.Panel2.Controls.Add(this.reeipanel);
            this.splitContainer1.Size = new System.Drawing.Size(556, 386);
            this.splitContainer1.SplitterDistance = 157;
            this.splitContainer1.TabIndex = 0;
            // 
            // tv1
            // 
            this.tv1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tv1.Location = new System.Drawing.Point(0, 0);
            this.tv1.Name = "tv1";
            treeNode1.Name = "Node6";
            treeNode1.Text = "Normal";
            treeNode2.Name = "Node7";
            treeNode2.Text = "Grouped";
            treeNode3.Name = "Node5";
            treeNode3.Text = "View";
            treeNode4.Name = "Node0";
            treeNode4.Text = "Script Editor";
            treeNode5.Name = "Node4";
            treeNode5.Text = "Viewer";
            treeNode6.Name = "Node3";
            treeNode6.Text = "Reference Editor";
            this.tv1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode6});
            this.tv1.Size = new System.Drawing.Size(157, 386);
            this.tv1.TabIndex = 0;
            this.tv1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tv1_AfterSelect);
            // 
            // seviewnormpanel
            // 
            this.seviewnormpanel.Controls.Add(this.splitContainer2);
            this.seviewnormpanel.Controls.Add(this.replacebox);
            this.seviewnormpanel.Controls.Add(this.button9);
            this.seviewnormpanel.Controls.Add(this.button3);
            this.seviewnormpanel.Controls.Add(this.findbox);
            this.seviewnormpanel.Controls.Add(this.button1);
            this.seviewnormpanel.Controls.Add(this.label5);
            this.seviewnormpanel.Controls.Add(this.scriptbox);
            this.seviewnormpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.seviewnormpanel.Location = new System.Drawing.Point(0, 0);
            this.seviewnormpanel.Name = "seviewnormpanel";
            this.seviewnormpanel.Size = new System.Drawing.Size(395, 386);
            this.seviewnormpanel.TabIndex = 1;
            this.seviewnormpanel.Visible = false;
            this.seviewnormpanel.VisibleChanged += new System.EventHandler(this.seviewnormpanel_VisibleChanged);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(13, 347);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.button2);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.button4);
            this.splitContainer2.Size = new System.Drawing.Size(368, 23);
            this.splitContainer2.SplitterDistance = 184;
            this.splitContainer2.TabIndex = 31;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Enabled = false;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(184, 23);
            this.button2.TabIndex = 29;
            this.button2.Text = "Save to file";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gray;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(180, 23);
            this.button4.TabIndex = 30;
            this.button4.Text = "Open file";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // replacebox
            // 
            this.replacebox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.replacebox.Location = new System.Drawing.Point(13, 68);
            this.replacebox.Name = "replacebox";
            this.replacebox.Size = new System.Drawing.Size(278, 20);
            this.replacebox.TabIndex = 28;
            this.replacebox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.findbox_PreviewKeyDown);
            this.replacebox.TextChanged += new System.EventHandler(this.replacebox_TextChanged);
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button9.BackColor = System.Drawing.Color.LightSlateGray;
            this.button9.Enabled = false;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(297, 66);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(84, 23);
            this.button9.TabIndex = 27;
            this.button9.Text = "Replace";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.button3.Enabled = false;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(297, 37);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 23);
            this.button3.TabIndex = 26;
            this.button3.Text = "Find";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // findbox
            // 
            this.findbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.findbox.Location = new System.Drawing.Point(13, 39);
            this.findbox.Name = "findbox";
            this.findbox.Size = new System.Drawing.Size(278, 20);
            this.findbox.TabIndex = 25;
            this.findbox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.findbox_PreviewKeyDown);
            this.findbox.TextChanged += new System.EventHandler(this.findbox_TextChanged);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.Enabled = false;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(13, 319);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(368, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Save changes to map";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(235, 24);
            this.label5.TabIndex = 22;
            this.label5.Text = "Script Editor - Normal View";
            // 
            // scriptbox
            // 
            this.scriptbox.AcceptsReturn = true;
            this.scriptbox.AcceptsTab = true;
            this.scriptbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.scriptbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scriptbox.HideSelection = false;
            this.scriptbox.Location = new System.Drawing.Point(13, 95);
            this.scriptbox.MaxLength = 999999999;
            this.scriptbox.Multiline = true;
            this.scriptbox.Name = "scriptbox";
            this.scriptbox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.scriptbox.Size = new System.Drawing.Size(368, 218);
            this.scriptbox.TabIndex = 23;
            this.scriptbox.WordWrap = false;
            this.scriptbox.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.findbox_PreviewKeyDown);
            this.scriptbox.TextChanged += new System.EventHandler(this.scriptbox_TextChanged);
            // 
            // reeipanel
            // 
            this.reeipanel.Controls.Add(this.listv);
            this.reeipanel.Controls.Add(this.button12);
            this.reeipanel.Controls.Add(this.button10);
            this.reeipanel.Controls.Add(this.label13);
            this.reeipanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reeipanel.Location = new System.Drawing.Point(0, 0);
            this.reeipanel.Name = "reeipanel";
            this.reeipanel.Size = new System.Drawing.Size(395, 386);
            this.reeipanel.TabIndex = 4;
            this.reeipanel.Visible = false;
            this.reeipanel.VisibleChanged += new System.EventHandler(this.reeipanel_VisibleChanged);
            // 
            // listv
            // 
            this.listv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listv.FullRowSelect = true;
            this.listv.GridLines = true;
            this.listv.Location = new System.Drawing.Point(13, 37);
            this.listv.Name = "listv";
            this.listv.Size = new System.Drawing.Size(368, 330);
            this.listv.TabIndex = 24;
            this.listv.UseCompatibleStateImageBehavior = false;
            this.listv.View = System.Windows.Forms.View.Details;
            this.listv.Resize += new System.EventHandler(this.listv_Resize);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Reference";
            this.columnHeader1.Width = 243;
            // 
            // button12
            // 
            this.button12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button12.BackColor = System.Drawing.Color.DarkGray;
            this.button12.Enabled = false;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(94, 344);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 26;
            this.button12.Text = "Inject";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Visible = false;
            // 
            // button10
            // 
            this.button10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button10.BackColor = System.Drawing.Color.DarkGray;
            this.button10.Enabled = false;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(13, 344);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 25;
            this.button10.Text = "Extract";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(8, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(227, 24);
            this.label13.TabIndex = 22;
            this.label13.Text = "Reference Editor - Viewer";
            // 
            // repanel
            // 
            this.repanel.Controls.Add(this.label8);
            this.repanel.Controls.Add(this.button8);
            this.repanel.Controls.Add(this.progressBar3);
            this.repanel.Controls.Add(this.label9);
            this.repanel.Controls.Add(this.label11);
            this.repanel.Controls.Add(this.label12);
            this.repanel.Controls.Add(this.progressBar4);
            this.repanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.repanel.Location = new System.Drawing.Point(0, 0);
            this.repanel.Name = "repanel";
            this.repanel.Size = new System.Drawing.Size(395, 386);
            this.repanel.TabIndex = 3;
            this.repanel.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(83, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "Overall Size: 0";
            // 
            // button8
            // 
            this.button8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button8.BackColor = System.Drawing.Color.CadetBlue;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(281, 48);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(84, 49);
            this.button8.TabIndex = 18;
            this.button8.Text = "Load References";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // progressBar3
            // 
            this.progressBar3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar3.Location = new System.Drawing.Point(13, 115);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(368, 10);
            this.progressBar3.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(8, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 24);
            this.label9.TabIndex = 22;
            this.label9.Text = "Reference Editor";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(33, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Amount of References: 0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(29, 48);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(129, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Offset of 1st Reference: 0";
            // 
            // progressBar4
            // 
            this.progressBar4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar4.Location = new System.Drawing.Point(13, 37);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(368, 72);
            this.progressBar4.TabIndex = 19;
            // 
            // sepanel
            // 
            this.sepanel.Controls.Add(this.label6);
            this.sepanel.Controls.Add(this.button5);
            this.sepanel.Controls.Add(this.progressBar2);
            this.sepanel.Controls.Add(this.label4);
            this.sepanel.Controls.Add(this.label3);
            this.sepanel.Controls.Add(this.label2);
            this.sepanel.Controls.Add(this.label1);
            this.sepanel.Controls.Add(this.progressBar1);
            this.sepanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sepanel.Location = new System.Drawing.Point(0, 0);
            this.sepanel.Name = "sepanel";
            this.sepanel.Size = new System.Drawing.Size(395, 386);
            this.sepanel.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(29, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Position in Map: 0";
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.BackColor = System.Drawing.Color.CadetBlue;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(281, 48);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(84, 67);
            this.button5.TabIndex = 18;
            this.button5.Text = "Load Script";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // progressBar2
            // 
            this.progressBar2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar2.Location = new System.Drawing.Point(13, 133);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(368, 10);
            this.progressBar2.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 24);
            this.label4.TabIndex = 22;
            this.label4.Text = "Script Editor";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(24, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Classes in Script: 0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(38, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Script Length: 0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(43, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Script Offset: 0";
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(13, 37);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(368, 90);
            this.progressBar1.TabIndex = 19;
            // 
            // seviewgpanel
            // 
            this.seviewgpanel.Controls.Add(this.splitContainer3);
            this.seviewgpanel.Controls.Add(this.button11);
            this.seviewgpanel.Controls.Add(this.label7);
            this.seviewgpanel.Controls.Add(this.splitContainer4);
            this.seviewgpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.seviewgpanel.Location = new System.Drawing.Point(0, 0);
            this.seviewgpanel.Name = "seviewgpanel";
            this.seviewgpanel.Size = new System.Drawing.Size(395, 386);
            this.seviewgpanel.TabIndex = 2;
            this.seviewgpanel.Visible = false;
            this.seviewgpanel.VisibleChanged += new System.EventHandler(this.seviewbdpanel_VisibleChanged);
            // 
            // splitContainer3
            // 
            this.splitContainer3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(13, 347);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.button6);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.button7);
            this.splitContainer3.Size = new System.Drawing.Size(368, 23);
            this.splitContainer3.SplitterDistance = 184;
            this.splitContainer3.TabIndex = 31;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Gray;
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.Enabled = false;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(0, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(184, 23);
            this.button6.TabIndex = 29;
            this.button6.Text = "Save to file";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Gray;
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(0, 0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(180, 23);
            this.button7.TabIndex = 30;
            this.button7.Text = "Open file";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button11
            // 
            this.button11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.button11.BackColor = System.Drawing.Color.DarkGray;
            this.button11.Enabled = false;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(13, 319);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(368, 23);
            this.button11.TabIndex = 24;
            this.button11.Text = "Save changes to map";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(8, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(249, 24);
            this.label7.TabIndex = 22;
            this.label7.Text = "Script Editor - Grouped View";
            // 
            // splitContainer4
            // 
            this.splitContainer4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer4.Location = new System.Drawing.Point(13, 37);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.tv2);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.panel3);
            this.splitContainer4.Size = new System.Drawing.Size(368, 274);
            this.splitContainer4.SplitterDistance = 206;
            this.splitContainer4.SplitterWidth = 2;
            this.splitContainer4.TabIndex = 32;
            // 
            // tv2
            // 
            this.tv2.AllowDrop = true;
            this.tv2.ContextMenuStrip = this.ctms2;
            this.tv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tv2.HideSelection = false;
            this.tv2.Location = new System.Drawing.Point(0, 0);
            this.tv2.Name = "tv2";
            this.tv2.Size = new System.Drawing.Size(206, 274);
            this.tv2.TabIndex = 1;
            this.tv2.DragDrop += new System.Windows.Forms.DragEventHandler(this.tv2_DragDrop);
            this.tv2.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tv2_AfterSelect);
            this.tv2.DragEnter += new System.Windows.Forms.DragEventHandler(this.tv2_DragEnter);
            this.tv2.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.tv2_ItemDrag);
            // 
            // ctms2
            // 
            this.ctms2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rtool,
            this.rmtool,
            this.stool,
            this.atool});
            this.ctms2.Name = "ctms1";
            this.ctms2.ShowImageMargin = false;
            this.ctms2.Size = new System.Drawing.Size(132, 76);
            this.ctms2.Opening += new System.ComponentModel.CancelEventHandler(this.ctms2_Opening);
            // 
            // rtool
            // 
            this.rtool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ttb1,
            this.renamet});
            this.rtool.Name = "rtool";
            this.rtool.Size = new System.Drawing.Size(131, 22);
            this.rtool.Text = "Rename";
            this.rtool.DropDownOpening += new System.EventHandler(this.rtool_DropDownOpening);
            // 
            // ttb1
            // 
            this.ttb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ttb1.Name = "ttb1";
            this.ttb1.Size = new System.Drawing.Size(100, 21);
            this.ttb1.TextChanged += new System.EventHandler(this.ttb1_TextChanged);
            // 
            // renamet
            // 
            this.renamet.Enabled = false;
            this.renamet.Name = "renamet";
            this.renamet.Size = new System.Drawing.Size(160, 22);
            this.renamet.Text = "Rename";
            this.renamet.Click += new System.EventHandler(this.renamet_Click);
            // 
            // rmtool
            // 
            this.rmtool.Name = "rmtool";
            this.rmtool.Size = new System.Drawing.Size(131, 22);
            this.rmtool.Text = "Remove";
            this.rmtool.Click += new System.EventHandler(this.rmtool_Click);
            // 
            // stool
            // 
            this.stool.Name = "stool";
            this.stool.Size = new System.Drawing.Size(128, 6);
            // 
            // atool
            // 
            this.atool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ttb2,
            this.addt});
            this.atool.Name = "atool";
            this.atool.Size = new System.Drawing.Size(131, 22);
            this.atool.Text = "Add classname";
            // 
            // ttb2
            // 
            this.ttb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ttb2.Name = "ttb2";
            this.ttb2.Size = new System.Drawing.Size(100, 21);
            this.ttb2.TextChanged += new System.EventHandler(this.ttb2_TextChanged);
            // 
            // addt
            // 
            this.addt.Enabled = false;
            this.addt.Name = "addt";
            this.addt.Size = new System.Drawing.Size(160, 22);
            this.addt.Text = "Add";
            this.addt.Click += new System.EventHandler(this.addt_Click);
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.ContextMenuStrip = this.ctms3;
            this.panel3.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(160, 274);
            this.panel3.TabIndex = 12;
            this.panel3.Resize += new System.EventHandler(this.panel3_Resize);
            // 
            // ctms3
            // 
            this.ctms3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rt,
            this.rmt,
            this.st,
            this.at});
            this.ctms3.Name = "ctms1";
            this.ctms3.ShowImageMargin = false;
            this.ctms3.Size = new System.Drawing.Size(125, 76);
            this.ctms3.Opening += new System.ComponentModel.CancelEventHandler(this.ctms3_Opening);
            // 
            // rt
            // 
            this.rt.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ttb3,
            this.rentool});
            this.rt.Name = "rt";
            this.rt.Size = new System.Drawing.Size(124, 22);
            this.rt.Text = "Rename";
            this.rt.DropDownOpening += new System.EventHandler(this.rt_DropDownOpening);
            // 
            // ttb3
            // 
            this.ttb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ttb3.Name = "ttb3";
            this.ttb3.Size = new System.Drawing.Size(100, 21);
            this.ttb3.TextChanged += new System.EventHandler(this.ttb3_TextChanged);
            // 
            // rentool
            // 
            this.rentool.Enabled = false;
            this.rentool.Name = "rentool";
            this.rentool.Size = new System.Drawing.Size(160, 22);
            this.rentool.Text = "Rename";
            this.rentool.Click += new System.EventHandler(this.rentool_Click);
            // 
            // rmt
            // 
            this.rmt.Name = "rmt";
            this.rmt.Size = new System.Drawing.Size(124, 22);
            this.rmt.Text = "Remove";
            this.rmt.Click += new System.EventHandler(this.rmt_Click);
            // 
            // st
            // 
            this.st.Name = "st";
            this.st.Size = new System.Drawing.Size(121, 6);
            // 
            // at
            // 
            this.at.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ttb4,
            this.ttb5,
            this.adtol});
            this.at.Name = "at";
            this.at.Size = new System.Drawing.Size(124, 22);
            this.at.Text = "Add property";
            // 
            // ttb4
            // 
            this.ttb4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ttb4.Name = "ttb4";
            this.ttb4.Size = new System.Drawing.Size(100, 21);
            this.ttb4.Text = "Name";
            this.ttb4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ttb4_MouseDown);
            this.ttb4.TextChanged += new System.EventHandler(this.ttb4_TextChanged);
            // 
            // ttb5
            // 
            this.ttb5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ttb5.Name = "ttb5";
            this.ttb5.Size = new System.Drawing.Size(100, 21);
            this.ttb5.Text = "Value";
            this.ttb5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ttb5_MouseDown);
            // 
            // adtol
            // 
            this.adtol.Name = "adtol";
            this.adtol.Size = new System.Drawing.Size(160, 22);
            this.adtol.Text = "Add";
            this.adtol.Click += new System.EventHandler(this.adtol_Click);
            // 
            // o
            // 
            this.o.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            this.o.Title = "Open Script";
            // 
            // s
            // 
            this.s.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            this.s.Title = "Save Script as...";
            // 
            // ox
            // 
            this.ox.Filter = "XZP Files (*.xzp)|*.xzp";
            this.ox.Title = "Open XZP";
            // 
            // Mapform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 386);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Mapform";
            this.Text = "Form4";
            this.Activated += new System.EventHandler(this.Form4_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form4_FormClosing);
            this.Load += new System.EventHandler(this.Form4_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.seviewnormpanel.ResumeLayout(false);
            this.seviewnormpanel.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.reeipanel.ResumeLayout(false);
            this.reeipanel.PerformLayout();
            this.repanel.ResumeLayout(false);
            this.repanel.PerformLayout();
            this.sepanel.ResumeLayout(false);
            this.sepanel.PerformLayout();
            this.seviewgpanel.ResumeLayout(false);
            this.seviewgpanel.PerformLayout();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.ResumeLayout(false);
            this.ctms2.ResumeLayout(false);
            this.ctms3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView tv1;
        private System.Windows.Forms.Panel sepanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel seviewnormpanel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox scriptbox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox replacebox;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox findbox;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.OpenFileDialog o;
        private System.Windows.Forms.SaveFileDialog s;
        private System.Windows.Forms.ContextMenuStrip ctms3;
        private System.Windows.Forms.ToolStripMenuItem rt;
        private System.Windows.Forms.ToolStripTextBox ttb3;
        private System.Windows.Forms.ToolStripMenuItem rentool;
        private System.Windows.Forms.ToolStripMenuItem rmt;
        private System.Windows.Forms.ToolStripSeparator st;
        private System.Windows.Forms.ToolStripMenuItem at;
        private System.Windows.Forms.ToolStripTextBox ttb4;
        private System.Windows.Forms.ToolStripTextBox ttb5;
        private System.Windows.Forms.ToolStripMenuItem adtol;
        private System.Windows.Forms.ContextMenuStrip ctms2;
        private System.Windows.Forms.ToolStripMenuItem rtool;
        private System.Windows.Forms.ToolStripTextBox ttb1;
        private System.Windows.Forms.ToolStripMenuItem renamet;
        private System.Windows.Forms.ToolStripMenuItem rmtool;
        private System.Windows.Forms.ToolStripSeparator stool;
        private System.Windows.Forms.ToolStripMenuItem atool;
        private System.Windows.Forms.ToolStripTextBox ttb2;
        private System.Windows.Forms.ToolStripMenuItem addt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel seviewgpanel;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel repanel;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.Panel reeipanel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ListView listv;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.OpenFileDialog ox;
        private System.Windows.Forms.TreeView tv2;
        private System.Windows.Forms.Label label8;
    }
}